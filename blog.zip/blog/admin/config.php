<?php 
// $server="localhost";
// $username="root";
// $password="";
// $database="blog"
    $conn = mysqli_connect("localhost","root","","blog");
    // if ($conn){
    //     echo "success";
    // }
    // else{
    //     die ("connection fail");
    // }


?>